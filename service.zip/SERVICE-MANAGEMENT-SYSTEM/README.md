# spring-boot-form-handling-jsp
Project code for Spring Boot Form Handling with Spring Form Tags and JSP
### Read the article: [Spring Boot Form Handling Tutorial with Spring Form Tags and JSP](https://www.codejava.net/frameworks/spring-boot/spring-boot-form-handling-tutorial-with-spring-form-tags-and-jsp) 
### Watch video on YouTube: [Spring Boot Form Handling with Spring Form tags and JSP)](https://youtu.be/dvL7Xp01HYc)
