package net.codejava;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MvcController {
	
	@RequestMapping("/")
	public String home() {
		System.out.println("Going home...");
		return "index";
	}
	
	@GetMapping("/register")
	public String showForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		
		List<String> professionList = Arrays.asList("Developer", "Designer", "Tester", "Architect");
		model.addAttribute("professionList", professionList);
		
		return "register_form";
	}
	@GetMapping("/contact")
	public String showForm1(Model model) {
		User user = new User();
		return "contact";
	}
	@GetMapping("/info")
	public String showForm2(Model model) {
		User user = new User();
		return "info";
	}
	
	
	@GetMapping("/login")
	public String showForm8(Model model) {
		User user = new User();
		return "login";
	}
	@GetMapping("/banking")
	public String showForm11(Model model) {
		User user = new User();
		return "banking";
	}
	
	@GetMapping("/shopping")
	public String showForm12(Model model) {
		User user = new User();
		return "shopping";
	}
	
	@PostMapping("/register")
	public String submitForm(@ModelAttribute("user") User user) {
		System.out.println(user);
		return "register_success";
	}
	
	@PostMapping("/login")
	public String submitForm8(@ModelAttribute("user") User user) {
		System.out.println(user);
		return "login_details";
	}
	
}
